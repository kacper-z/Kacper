
public class Runner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Okno okno=new Okno();
		okno.setVisible(true);

	}

}
